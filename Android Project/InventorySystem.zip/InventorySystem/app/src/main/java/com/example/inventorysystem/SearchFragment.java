package com.example.inventorysystem;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SearchFragment extends Fragment {

    String user, permissions;

    ImageButton btnAddBarcode;
    EditText txtBarcode, txtItemName;
    Button btnBarcodeSearch, btnNameSearch;
    TableLayout tblResults;

    Connection connection;
    String server, database, username, password;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        Bundle bundle = this.getArguments();
        user = bundle.getString("user");

        View view = inflater.inflate(R.layout.fragment_search, null);

        btnAddBarcode = view.findViewById(R.id.btnAddBarcode);
        btnBarcodeSearch = view.findViewById(R.id.btnBarcodeSearch);
        btnNameSearch = view.findViewById(R.id.btnNameSearch);
        tblResults = view.findViewById(R.id.tblResults);
        txtBarcode = view.findViewById(R.id.txtBarcode);
        txtItemName = view.findViewById(R.id.txtItemName);

        server = "3.16.210.106:3306/";
        database = "Inventory";
        username = "akstraw";
        password = "abcde";

        btnBarcodeSearch.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                SearchFragment.SearchBarcode searchBarcode = new SearchFragment.SearchBarcode();// Async Task
                searchBarcode.execute("");
            }
        });

        btnNameSearch.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                SearchFragment.SearchName searchName = new SearchFragment.SearchName();// Async Task
                searchName.execute("");
            }
        });

        return view;
    }

    public class SearchBarcode extends AsyncTask<String,String,String>
    {
        String message  = "";
        Boolean isSuccess = false;

        @Override
        protected void onPostExecute(String r)
        {
            if(!isSuccess)
            {
                Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
            }
        }
        @Override
        protected String doInBackground(String... params)
        {
            // try to find an item for the specific barcode entered
            // to do, add reset for table per each search, currently search results are appended
            try {
                connection = connectionclass(username, password, database, server);        // Connect to database
                if (connection == null) {
                    message = "Check Your Internet Access!";
                } else {

                    if (!txtBarcode.getText().toString().equals("")) {

                        // Change below query according to your own database.
                        String query = "select items.upc, items.name, sells.price, sells.on_hand\n" +
                                "from sells \n" +
                                "join items on sells.upc = items.upc\n" +
                                "join stores on stores.num = sells.store\n" +
                                "join employs on employs.store = stores.num\n" +
                                "join employees on employees.userid = employs.employee\n" +
                                "where items.upc like '%" + txtBarcode.getText().toString() + "%' \n" +
                                "and stores.num = (select employs.store \n" +
                                "from employs \n" +
                                "join employees on employees.userid = employs.employee \n" +
                                "where employs.employee = '" + user + "')";
                        Statement stmt = connection.createStatement();
                        ResultSet rs = stmt.executeQuery(query);

                        // only perform once because one barcode goes to one item, however, reuse
                        // this as needed (and change the uppermost for condition) to dynamically
                        // add result table rows for each returned item
                        for (int j = 0; j < 1 && rs.next(); ++j) {
                            TableRow tr = new TableRow(getActivity());

                            tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT));

                            for (int i = 1; i < 5; ++i) {
                                TextView tv = new TextView(getActivity());
                                tv.setText(rs.getString(i));

                                tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT, 1f));

                                tr.addView(tv);
                            }

                            final TableRow tr2 = tr;

                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    tblResults.addView(tr2, new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.MATCH_PARENT));
                                }
                            });


                        }

                        connection.close();
                        isSuccess = true;

                    }
                    else {
                        message = "Missing required information";
                    }
                }
            }
            catch (Exception ex) {
                isSuccess = false;
                message = ex.getMessage();
            }
            return message;
        }

        @SuppressLint("NewApi")
        public Connection connectionclass(String user, String password, String database, String server)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Connection connection = null;
            String ConnectionURL;
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection("jdbc:mysql://" + server + database, username, password);        // Connect to database
            }
            catch (SQLException se)
            {
                Log.e("error here 1 : ", se.getMessage());
            }
            catch (ClassNotFoundException e)
            {
                Log.e("error here 2 : ", e.getMessage());
            }
            catch (Exception e)
            {
                Log.e("error here 3 : ", e.getMessage());
            }
            return connection;
        }
    }

    //todo: add functionality for this
    public class SearchName extends AsyncTask<String,String,String>
    {
        String message = "";
        Boolean isSuccess = false;

        @Override
        protected void onPostExecute(String r)
        {
            if(!isSuccess)
            {
                Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
            }
        }
        @Override
        protected String doInBackground(String... params)
        {
            try {
                connection = connectionclass(username, password, database, server);        // Connect to database
                if (connection == null) {
                    message = "Check Your Internet Access!";
                } else {

                    
                    }
                    
                
            }
            catch (Exception ex) {
                isSuccess = false;
                message = ex.getMessage();
            }
            return message;
        }

        // Establish connection asynchronously
        @SuppressLint("NewApi")
        public Connection connectionclass(String user, String password, String database, String server)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Connection connection = null;
            String ConnectionURL;
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection("jdbc:mysql://" + server + database, username, password);        // Connect to database
            }
            catch (SQLException se)
            {
                Log.e("error here 1 : ", se.getMessage());
            }
            catch (ClassNotFoundException e)
            {
                Log.e("error here 2 : ", e.getMessage());
            }
            catch (Exception e)
            {
                Log.e("error here 3 : ", e.getMessage());
            }
            return connection;
        }
    }
}
