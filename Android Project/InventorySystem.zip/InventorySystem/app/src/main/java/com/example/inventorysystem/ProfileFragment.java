package com.example.inventorysystem;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ProfileFragment extends Fragment {

    String user;

    TextView lblName;
    TextView lblJobTitle;
    TextView lblStoreAddress;
    TextView lblStoreCity;
    TextView lblPermissions;

    Connection connection;
    String server, database, username, password;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        Bundle bundle = this.getArguments();
        user = bundle.getString("user");

        View view = inflater.inflate(R.layout.fragment_profile, null);

        lblName = view.findViewById(R.id.lblName);
        lblJobTitle = view.findViewById(R.id.lblJobTitle);
        lblStoreAddress = view.findViewById(R.id.lblStoreAddress);
        lblStoreCity = view.findViewById(R.id.lblStoreCity);
        lblPermissions = view.findViewById(R.id.lblPermissions);

        server = "3.16.210.106:3306/";
        database = "Inventory";
        username = "akstraw";
        password = "abcde";

        PopulateControls populateControls = new PopulateControls();// Async task
        populateControls.execute("");

        return view;
    }

    public class PopulateControls extends AsyncTask<String,String,String>
    {
        String message = "";
        Boolean isSuccess = false;

        @Override
        protected void onPostExecute(String r)
        {
            //Toast.makeText(HomeActivity.this, r, Toast.LENGTH_SHORT).show();
            if(isSuccess)
            {
                //finish();
            }
        }
        @Override
        protected String doInBackground(String... params)
        {
            // Try to pull all information related to user, such as position, store, and permissions
            try {
                connection = connectionclass(username, password, database, server);        // Connect to database
                if (connection == null) {
                    message = "Check Your Internet Access!";
                } else {
                    String query = "select users.name, users.job_title, stores.addr, stores.city " +
                            "from employees as users " +
                            "join employs on users.userid = employs.employee " +
                            "join stores on employs.store = stores.num " +
                            "where users.userid = '" + user +"'";
                    Statement stmt = connection.createStatement();
                    ResultSet rs = stmt.executeQuery(query);
                    if (rs.next()) {

                        final String name = rs.getString("name");
                        final String jobTitle = rs.getString("job_title");
                        final String addr = rs.getString("addr");
                        final String city = rs.getString("city");
                        new Handler(Looper.getMainLooper()).post(new Runnable(){
                            @Override
                            public void run() {
                                lblName.setText(name);
                                lblJobTitle.setText(jobTitle);
                                lblStoreAddress.setText(addr);
                                lblStoreCity.setText(city);
                            }
                        });
                        query = "select permissions.command " +
                                "from employees as users " +
                                "join permissions on permissions.employee = users.userid " +
                                "where users.userid = '" + user + "'";
                        stmt = connection.createStatement();
                        rs = stmt.executeQuery(query);

                        while (rs.next()) {
                            lblPermissions.append(rs.getString("command") + "\n");
                        }

                        connection.close();
                        isSuccess = true;
                    } else {
                        isSuccess = false;
                    }
                }
            }
            catch (Exception ex) {
                isSuccess = false;
                message = ex.getMessage();
            }
            return message;
        }

        // Establish connection asynchronously
        @SuppressLint("NewApi")
        public Connection connectionclass(String user, String password, String database, String server)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Connection connection = null;
            String ConnectionURL;
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection("jdbc:mysql://" + server + database, username, password);        // Connect to database
            }
            catch (SQLException se)
            {
                Log.e("error here 1 : ", se.getMessage());
            }
            catch (ClassNotFoundException e)
            {
                Log.e("error here 2 : ", e.getMessage());
            }
            catch (Exception e)
            {
                Log.e("error here 3 : ", e.getMessage());
            }
            return connection;
        }
    }
}
