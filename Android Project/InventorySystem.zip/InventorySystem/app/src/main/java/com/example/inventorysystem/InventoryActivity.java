package com.example.inventorysystem;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

public class InventoryActivity extends AppCompatActivity
        implements BottomNavigationView.OnNavigationItemSelectedListener {

    String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Receive username from prior activity
        Intent intent = getIntent();
        user = intent.getStringExtra("user");

        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(this);

        loadFragment(new ProfileFragment());
    }

    // Ensures seamless transition between fragments and that each fragment
    // can receive the userID of the user
    public boolean loadFragment(Fragment fragment) {
        if(fragment != null) {

            Bundle bundle = new Bundle();
            bundle.putString("user", user);
            fragment.setArguments(bundle);

            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();

            return true;
        }
        return false;
    }

    // Transitions to fragment for desired item selection
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Fragment fragment = null;

        switch (item.getItemId()) {
            case R.id.navigation_profile:
                fragment = new ProfileFragment();
                break;

            case R.id.navigation_manage:
                fragment = new ManageFragment();
                break;

            case R.id.navigation_search:
                fragment = new SearchFragment();
                break;

            case R.id.navigation_sell:
                fragment = new SellFragment();
                break;

        }

        return loadFragment(fragment);
    }
}
