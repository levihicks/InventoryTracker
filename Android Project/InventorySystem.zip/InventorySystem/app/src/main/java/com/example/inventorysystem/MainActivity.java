package com.example.inventorysystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MainActivity extends AppCompatActivity {

    Button btnLogin;
    EditText txtUsername;
    EditText txtPassword;

    Connection connection;
    String server, database, username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLogin = findViewById(R.id.btnLogin);
        txtUsername = findViewById(R.id.txtUsername);
        txtPassword = findViewById(R.id.txtPassword);

        server = "3.16.210.106:3306/";
        database = "Inventory";
        username = "akstraw";
        password = "abcde";

        btnLogin.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                CheckLogin checkLogin = new CheckLogin();// this is the Asynctask, which is used to process in background to reduce load on app process
                checkLogin.execute("");
            }
        });
    }

    public class CheckLogin extends AsyncTask<String,String,String>
    {
        String message = "";
        Boolean isSuccess = false;

        @Override
        protected void onPostExecute(String r)
        {
            //If credentials are valid, go to inventory activity, pass user ID to new activity
            Toast.makeText(MainActivity.this, r, Toast.LENGTH_SHORT).show();
            if(isSuccess)
            {
                //Toast.makeText(LoginActivity.this , "Login Successful" , Toast.LENGTH_LONG).show();
                Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
                intent.putExtra("user", txtUsername.getText().toString());
                startActivity(intent);
                //finish();
            }
        }
        @Override
        protected String doInBackground(String... params)
        {
            // check for empty parameters
            String usernam = txtUsername.getText().toString();
            String passwordd = txtPassword.getText().toString();
            if(usernam.trim().equals("")|| passwordd.trim().equals(""))
                message = "Please enter Username and Password";
            else
            {
                // try to verify credentials
                try
                {
                    connection = connectionclass(username, password, database, server);        // Connect to database
                    if (connection == null)
                    {
                        message = "Check Your Internet Access!";
                    }
                    else
                    {
                        String query = "select 1 from employees where userid= '" + usernam + "' and pw = '"+ passwordd +"'  ";
                        Statement stmt = connection.createStatement();
                        ResultSet rs = stmt.executeQuery(query);
                        if(rs.next())
                        {
                            message = "Login successful";
                            isSuccess=true;
                            connection.close();
                        }
                        else
                        {
                            message = "Invalid Credentials!";
                            isSuccess = false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    isSuccess = false;
                    message = ex.getMessage();
                }
            }
            return message ;
        }

        // Establish connection asynchronously
        @SuppressLint("NewApi")
        public Connection connectionclass(String user, String password, String database, String server)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Connection connection = null;
            String ConnectionURL;
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection("jdbc:mysql://" + server + database, username, password);        // Connect to database
            }
            catch (SQLException se)
            {
                Log.e("error here 1 : ", se.getMessage());
            }
            catch (ClassNotFoundException e)
            {
                Log.e("error here 2 : ", e.getMessage());
            }
            catch (Exception e)
            {
                Log.e("error here 3 : ", e.getMessage());
            }
            return connection;
        }
    }
}
