package com.example.inventorysystem;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ManageFragment extends Fragment {

    String user, permissions;

    ImageButton btnAddBarcode;
    EditText txtBarcode, txtItemName, txtItemPrice, txtQuantity;
    Button btnSubmit, btnSave, btnClear;
    TextView lblAction;

    Connection connection;
    String server, database, username, password;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        Bundle bundle = this.getArguments();
        user = bundle.getString("user");

        View view = inflater.inflate(R.layout.fragment_manage, null);

        btnAddBarcode = view.findViewById(R.id.btnAddBarcode);
        txtBarcode = view.findViewById(R.id.txtBarcode);
        txtItemName = view.findViewById(R.id.txtItemName);
        txtItemPrice = view.findViewById(R.id.txtItemPrice);
        txtQuantity = view.findViewById(R.id.txtQuantity);
        btnSubmit = view.findViewById(R.id.btnSubmit);
        btnSave = view.findViewById(R.id.btnSave);
        btnClear = view.findViewById(R.id.btnClear);
        lblAction = view.findViewById(R.id.lblAction);

        server = "3.16.210.106:3306/";
        database = "Inventory";
        username = "akstraw";
        password = "abcde";

        PopulateControls populateControls = new PopulateControls(); // Async Task
        populateControls.execute("");

        btnSubmit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                LoadItem loadItem = new LoadItem(); // Async Task
                loadItem.execute("");
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                SaveItem saveItem = new SaveItem(); // Async Task
                saveItem.execute("");
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                txtBarcode.setText("");
                txtItemName.setText("");
                txtItemPrice.setText("");
                txtQuantity.setText("");
            }
        });

        return view;
    }

    public class PopulateControls extends AsyncTask<String,String,String>
    {
        String message = "";
        Boolean isSuccess = false;

        @Override
        protected void onPostExecute(String r)
        {
            //failure determined by lack of permissions required to operate activity
            if(!isSuccess)
            {
                Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();

                ProfileFragment nextFrag= new ProfileFragment();

                // Return to profile activity where user can inspect their permissions
                Bundle bundle = new Bundle();
                bundle.putString("user", user);
                nextFrag.setArguments(bundle);
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, nextFrag)
                        .addToBackStack(null)
                        .commit();
            }
        }
        @Override
        protected String doInBackground(String... params)
        {
            // Try to check for permissions and adjust controls functionality accordingly
            try {
                connection = connectionclass(username, password, database, server);        // Connect to database
                if (connection == null) {
                    message = "Check Your Internet Access!";
                } else {
                    String query = "select permissions.command " +
                            "from employees as users " +
                            "join permissions on permissions.employee = users.userid " +
                            "where users.userid = '" + user + "'";
                    Statement stmt = connection.createStatement();
                    ResultSet rs = stmt.executeQuery(query);

                    while (rs.next()) {
                        permissions += (rs.getString("command") + "\n");
                    }

                    connection.close();
                    isSuccess = true;

                    if (!permissions.contains("set count") && !permissions.contains("set price")) {
                        isSuccess = false;
                        message = "You do not have permissions to access this";
                    }
                    else if (!permissions.contains("set count")){
                        txtQuantity.setInputType(InputType.TYPE_NULL);
                        txtQuantity.setClickable(false);
                        txtQuantity.setCursorVisible(false);
                        txtQuantity.setFocusable(false);
                        txtQuantity.setFocusableInTouchMode(false);
                    }
                    else if (!permissions.contains("set price")){
                        txtItemPrice.setInputType(InputType.TYPE_NULL);
                        txtItemPrice.setClickable(false);
                        txtItemPrice.setCursorVisible(false);
                        txtItemPrice.setFocusable(false);
                        txtItemPrice.setFocusableInTouchMode(false);
                    }

                }
            }
            catch (Exception ex) {
                isSuccess = false;
                message = ex.getMessage();
            }
            return message;
        }

        // Establish connection asynchronously
        @SuppressLint("NewApi")
        public Connection connectionclass(String user, String password, String database, String server)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Connection connection = null;
            String ConnectionURL;
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection("jdbc:mysql://" + server + database, username, password);        // Connect to database
            }
            catch (SQLException se)
            {
                Log.e("error here 1 : ", se.getMessage());
            }
            catch (ClassNotFoundException e)
            {
                Log.e("error here 2 : ", e.getMessage());
            }
            catch (Exception e)
            {
                Log.e("error here 3 : ", e.getMessage());
            }
            return connection;
        }
    }

    public class LoadItem extends AsyncTask<String,String,String>
    {
        String message = "";
        Boolean isSuccess = false;

        @Override
        protected void onPostExecute(String r)
        {
            if(!isSuccess)
            {
                Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
            }
        }
        @Override
        protected String doInBackground(String... params)
        {
            // Try to load item details for editing
            try {
                if (txtBarcode.getText().toString() != "") {
                    connection = connectionclass(username, password, database, server);        // Connect to database
                    if (connection == null) {
                        message = "Check Your Internet Access!";
                    } else {
                        String query = "select items.name, sells.price, sells.on_hand\n" +
                                "from sells \n" +
                                "join items on sells.upc = items.upc\n" +
                                "join stores on stores.num = sells.store\n" +
                                "join employs on employs.store = stores.num\n" +
                                "join employees on employees.userid = employs.employee\n" +
                                "where items.upc = '" + txtBarcode.getText().toString() + "' \n" +
                                "and stores.num = (select employs.store \n" +
                                "from employs \n" +
                                "join employees on employees.userid = employs.employee \n" +
                                "where employs.employee = '" + user + "')";
                        Statement stmt = connection.createStatement();
                        ResultSet rs = stmt.executeQuery(query);

                        if (rs.next()) {
                            final String name = rs.getString("name");
                            final String price = rs.getString("price");
                            final String quantity = rs.getString("on_hand");
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                 @Override
                                 public void run() {
                                     txtItemName.setText(name);
                                     txtItemPrice.setText(price);
                                     txtQuantity.setText(quantity);
                                 }
                            });
                            isSuccess = true;
                        }
                        else { // Item did not exist in store inventory, check warehouse and add
                                // to the store inventory if item exists, then load item details
                            query = "select items.name\n" +
                                    "from items\n" +
                                    "where items.upc = '" + txtBarcode.getText().toString() + "' \n";
                            stmt = connection.createStatement();
                            rs = stmt.executeQuery(query);
                            if (rs.next()) {
                                query = "INSERT INTO sells VALUES ('"
                                        + txtBarcode.getText().toString()
                                        + "', (select employs.store \n" +
                                        "from employs \n" +
                                        "join employees on employees.userid = employs.employee \n" +
                                        "where employs.employee = '" + user + "'), 0.00, 0)";
                                stmt = connection.createStatement();
                                stmt.execute(query);
                                query = "select items.name, sells.price, sells.on_hand\n" +
                                        "from sells \n" +
                                        "join items on sells.upc = items.upc\n" +
                                        "join stores on stores.num = sells.store\n" +
                                        "join employs on employs.store = stores.num\n" +
                                        "join employees on employees.userid = employs.employee\n" +
                                        "where items.upc = '" + txtBarcode.getText().toString() + "' \n" +
                                        "and stores.num = (select employs.store \n" +
                                        "from employs \n" +
                                        "join employees on employees.userid = employs.employee \n" +
                                        "where employs.employee = '" + user + "')";
                                stmt = connection.createStatement();
                                rs = stmt.executeQuery(query);

                                if (rs.next()) {
                                    isSuccess = true;
                                    final String name = rs.getString("name");
                                    final String price = rs.getString("price");
                                    final String quantity = rs.getString("on_hand");
                                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                                        @Override
                                        public void run() {
                                            txtItemName.setText(name);
                                            txtItemPrice.setText(price);
                                            txtQuantity.setText(quantity);
                                        }
                                    });
                                }
                            }
                            else { // otherwise, add item to both warehouse and store, and add item
                                    // in such a way that the store can decide the name of the item
                                    // on this occasion only since the item is new
                                query = "Insert into itemsVALUES ('"
                                        + txtBarcode.getText().toString()
                                        + "', 0, Untitled, 0)";
                                stmt = connection.createStatement();
                                stmt.execute(query);
                                query = "INSERT INTO sells VALUES ('"
                                        + txtBarcode.getText().toString()
                                        + "', (select employs.store \n" +
                                        "from employs \n" +
                                        "join employees on employees.userid = employs.employee \n" +
                                        "where employs.employee = '" + user + "'), 0.00, 0)";
                                stmt = connection.createStatement();
                                stmt.execute(query);
                                query = "select items.name, sells.price, sells.on_hand\n" +
                                        "from sells \n" +
                                        "join items on sells.upc = items.upc\n" +
                                        "join stores on stores.num = sells.store\n" +
                                        "join employs on employs.store = stores.num\n" +
                                        "join employees on employees.userid = employs.employee\n" +
                                        "where items.upc = '" + txtBarcode.getText().toString() + "' \n" +
                                        "and stores.num = (select employs.store \n" +
                                        "from employs \n" +
                                        "join employees on employees.userid = employs.employee \n" +
                                        "where employs.employee = '" + user + "')";
                                stmt = connection.createStatement();
                                rs = stmt.executeQuery(query);

                                if (rs.next()) {
                                    isSuccess = true;
                                    final String name = rs.getString("name");
                                    final String price = rs.getString("price");
                                    final String quantity = rs.getString("on_hand");
                                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                                        @Override
                                        public void run() {
                                            txtItemName.setText(name);
                                            txtItemPrice.setText(price);
                                            txtQuantity.setText(quantity);
                                        }
                                    });
                                }
                            }

                        }

                        new Handler(Looper.getMainLooper()).post(new Runnable(){
                            @Override
                            public void run() {

                                // Adjust name textbox according to if the item is new and needs
                                // a name added, or if the name exists and should not be altered
                                if (!txtItemName.getText().toString().equals("Untitled")) {
                                    txtItemName.setInputType(InputType.TYPE_NULL);
                                    txtItemName.setClickable(false);
                                    txtItemName.setCursorVisible(false);
                                    txtItemName.setFocusable(false);
                                    txtItemName.setFocusableInTouchMode(false);
                                    txtItemName.setTextIsSelectable(false);
                                    txtItemName.setLongClickable(false);
                                }
                                else {
                                    txtItemName.setInputType(InputType.TYPE_CLASS_TEXT);
                                    txtItemName.setClickable(true);
                                    txtItemName.setCursorVisible(true);
                                    txtItemName.setFocusable(true);
                                    txtItemName.setFocusableInTouchMode(true);
                                    txtItemName.setTextIsSelectable(true);
                                    txtItemName.setLongClickable(true);
                                }
                            }
                        });

                        connection.close();
                        isSuccess = true;


                    }
                }
                else {
                    message = "Enter a barcode";
                }
            }
            catch (Exception ex) {
                isSuccess = false;
                message = ex.getMessage();
            }
            return message;
        }

        // Establish connection asynchronously
        @SuppressLint("NewApi")
        public Connection connectionclass(String user, String password, String database, String server)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Connection connection = null;
            String ConnectionURL;
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection("jdbc:mysql://" + server + database, username, password);        // Connect to database
            }
            catch (SQLException se)
            {
                Log.e("error here 1 : ", se.getMessage());
            }
            catch (ClassNotFoundException e)
            {
                Log.e("error here 2 : ", e.getMessage());
            }
            catch (Exception e)
            {
                Log.e("error here 3 : ", e.getMessage());
            }
            return connection;
        }
    }

    public class SaveItem extends AsyncTask<String,String,String>
    {
        String message = "";

        @Override
        protected void onPostExecute(String r)
        {
                Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
        }

        // save item details
        @Override
        protected String doInBackground(String... params)
        {
            try {
                connection = connectionclass(username, password, database, server);        // Connect to database
                if (connection == null) {
                    message = "Check Your Internet Access!";
                }
                else {

                    // check for empty parameters
                    if (!txtBarcode.getText().toString().equals("") &&
                            !txtItemName.getText().toString().equals("") &&
                            !txtItemPrice.getText().toString().equals("") &&
                            !txtQuantity.getText().toString().equals("")) {

                        String query;
                        Statement stmt;

                        // if item is new and meant to have a new name saved, update name in
                        // overarching items table
                        if (txtItemName.isClickable()) {
                            query = "update items " +
                                    "set name = '" + txtItemName.getText().toString() + "' " +
                                    "where upc = '" + txtBarcode.getText().toString() + "'";
                            stmt = connection.createStatement();
                            stmt.execute(query);
                        }

                        // update store specific inventory details
                        query = "update sells " +
                                "set price = '" + txtItemPrice.getText().toString() + "', " +
                                "on_hand = '" + txtQuantity.getText().toString() + "' " +
                                "where store = (select employs.store from employs " +
                                "join employees on employees.userid = employs.employee " +
                                "where employs.employee = '" + user + "')";
                        stmt = connection.createStatement();
                        stmt.execute(query);

                        message = "Item updated successfully";
                        connection.close();

                    }
                    else {
                        message = "Missing required information";
                    }
                }
            }
            catch (Exception ex) {
                message = ex.getMessage();
            }
            return message;
        }

        // Establish connection asynchronously
        @SuppressLint("NewApi")
        public Connection connectionclass(String user, String password, String database, String server)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Connection connection = null;
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection("jdbc:mysql://" + server + database, username, password);        // Connect to database
            }
            catch (SQLException se)
            {
                Log.e("error here 1 : ", se.getMessage());
            }
            catch (ClassNotFoundException e)
            {
                Log.e("error here 2 : ", e.getMessage());
            }
            catch (Exception e)
            {
                Log.e("error here 3 : ", e.getMessage());
            }
            return connection;
        }
    }
}
